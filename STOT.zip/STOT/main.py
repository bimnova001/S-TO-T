import sounddevice as sd
import numpy as np
import torch
from transformers import Speech2TextProcessor, Speech2TextForConditionalGeneration
import keyboard

# Function to record audio from the microphone until 'S' is pressed
def record_audio_until_s(fs=16000):
    print("Press 'S' to stop recording...")
    print("Eng only")
    audio_data = []
    
    # Callback function to append audio data to the list
    def callback(indata, frames, time, status):
        if status:
            print(status)
        audio_data.append(indata.copy())
    
    # Start recordings
    with sd.InputStream(samplerate=fs, channels=1, dtype='float32', callback=callback):
        while True:
            if keyboard.is_pressed('s'):  # Stop recording when 'S' is pressed
                break
    
    print("Recording finished.")
    return np.concatenate(audio_data)

# Load the pre-trained model and processor
model = Speech2TextForConditionalGeneration.from_pretrained("facebook/s2t-small-librispeech-asr", cache_dir="D:\huggingface_models")
processor = Speech2TextProcessor.from_pretrained("facebook/s2t-small-librispeech-asr", cache_dir="D:\huggingface_models")

# Record audio from the microphone until 'S' is pressed
audio_data = record_audio_until_s()  # Record until 'S' is pressed

# Ensure audio data is one-dimensional
if len(audio_data.shape) > 1:
    audio_data = audio_data.flatten()  # Flatten if necessary

# Print the shape of audio_data for debugging
print(f"Audio data shape: {audio_data.shape}")

# Process the recorded audio inputs
inputs = processor(audio_data, sampling_rate=16000, return_tensors="pt")

# Perform inference to generate transcriptions
with torch.no_grad():
    generated_ids = model.generate(inputs["input_features"], attention_mask=inputs["attention_mask"])

# Decode the generated IDs to get transcription text
transcription = processor.batch_decode(generated_ids, skip_special_tokens=True)

# Print the transcription
print(f"Transcription: {transcription[0]}")